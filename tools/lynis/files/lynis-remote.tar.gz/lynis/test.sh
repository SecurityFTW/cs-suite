if [[ -z "$5" && -z "$6" ]];then 
echo "cool"
echo "$#"
fi

